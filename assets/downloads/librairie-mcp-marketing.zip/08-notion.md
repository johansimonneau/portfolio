# Notion — connecteur MCP officiel

**Statut :** officiel, publié par Notion.
**Type de connexion :** distante recommandée (URL) ; une version locale
existe mais n'est plus activement maintenue.

## Comment se connecter (version recommandée, distante)

URL du serveur (Streamable HTTP, recommandée) :

```
https://mcp.notion.com/mcp
```

Une URL de repli en SSE est aussi documentée :

```
https://mcp.notion.com/sse
```

Avec Claude Code (ligne de commande) :

```
claude mcp add notion --transport http https://mcp.notion.com/mcp
```

Avec un client à interface graphique : ajoutez un connecteur personnalisé
dans les réglages et collez l'URL Streamable HTTP.

## Authentification

OAuth : le serveur respecte automatiquement les permissions déjà définies
dans votre espace Notion, sans jeton d'API ni configuration JSON à gérer.

## Version locale (auto-hébergée, non recommandée par défaut)

Notion documente aussi un serveur auto-hébergé, plus ancien et non
activement maintenu selon l'éditeur lui-même :

```json
{
  "mcpServers": {
    "notionApi": {
      "command": "npx",
      "args": ["-y", "@notionhq/notion-mcp-server"],
      "env": { "NOTION_TOKEN": "VOTRE_JETON_D_INTEGRATION" }
    }
  }
}
```

Ne l'utilisez que si vous avez un besoin spécifique non couvert par la
version distante officielle.

## Documentation officielle

https://developers.notion.com/guides/mcp/overview
https://github.com/makenotion/notion-mcp-server (version locale)
