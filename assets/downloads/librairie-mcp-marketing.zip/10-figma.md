# Figma (Dev Mode) — connecteur MCP officiel

**Statut :** officiel, intégré à l'application de bureau Figma.
**Type de connexion :** locale (serveur exposé sur votre machine par
l'application Figma elle-même — rien à installer séparément).

## Comment se connecter

1. Ouvrez l'application de bureau Figma (nécessite un accès Dev Mode, donc
   une licence Figma payante).
2. Dans Dev Mode, activez « Enable desktop MCP server » dans les
   préférences.
3. Le serveur est alors disponible en local à cette adresse :

```
http://127.0.0.1:3845/mcp
```

Configuration (format `mcpServers`) :

```json
{
  "mcpServers": {
    "figma-desktop": {
      "url": "http://127.0.0.1:3845/mcp"
    }
  }
}
```

## Authentification

Aucune authentification séparée : l'accès dépend uniquement du fait d'être
connecté à l'application de bureau Figma avec un accès Dev Mode.

## Documentation officielle

https://developers.figma.com/docs/figma-mcp-server/
