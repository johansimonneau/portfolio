# Semrush — connecteur MCP officiel

**Statut :** officiel, hébergé par Semrush.
**Type de connexion :** distante (URL, aucune installation).

## Comment se connecter

URL du serveur (v2, celle indiquée dans la documentation officielle pour les
clients récents) :

```
https://mcp.semrush.com/v2/mcp
```

Avec Claude Code (ligne de commande) :

```
claude mcp add semrush https://mcp.semrush.com/v2/mcp -t http
```

Avec un client à interface graphique (Claude.ai, ChatGPT, etc.) : dans les
réglages de connecteurs, ajoutez un connecteur personnalisé et collez cette
URL.

Une version v1 (`https://mcp.semrush.com/v1/mcp`) existe aussi dans la
documentation ; vérifiez sur la doc officielle laquelle correspond à votre
client au moment de la connexion, les éditeurs migrent parfois leurs clients
vers la dernière version disponible.

## Authentification

OAuth 2.1 par défaut (connexion à votre compte Semrush). Une clé d'API est
proposée en alternative pour les clients qui ne gèrent pas OAuth. Nécessite
un abonnement Semrush payant avec des unités d'API disponibles.

## Documentation officielle

https://www.semrush.com/mcp/
https://developer.semrush.com/api/v4/introduction/semrush-mcp/
