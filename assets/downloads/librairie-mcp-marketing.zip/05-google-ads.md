# Google Ads — connecteur MCP officiel

**Statut :** officiel, publié par Google (open source).
**Type de connexion :** locale (vous lancez le serveur vous-même).

## Comment se connecter

Paquet Python officiel `google-ads-mcp`, lancé via `pipx` :

```
pipx run --spec "google-ads-mcp==X.Y.Z" google-ads-mcp
```

(remplacez `X.Y.Z` par le numéro de version indiqué dans la documentation officielle)

Configuration (format `mcpServers`) :

```json
{
  "mcpServers": {
    "google-ads-mcp": {
      "command": "pipx",
      "args": ["run", "--spec", "git+https://github.com/googleads/google-ads-mcp.git", "google-ads-mcp"],
      "env": { "GOOGLE_APPLICATION_CREDENTIALS": "CHEMIN_VERS_VOS_IDENTIFIANTS.json" }
    }
  }
}
```

Un déploiement sur Google Cloud Run est aussi documenté officiellement, pour
un usage partagé par une équipe plutôt qu'en local.

## Authentification

Identifiants applicatifs par défaut de Google (Application Default
Credentials), ou fichier `google-ads.yaml` du client API Google Ads. Un
jeton développeur (developer token) est nécessaire pour un accès en
production.

## Documentation officielle

https://github.com/googleads/google-ads-mcp
