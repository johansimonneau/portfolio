# Google Analytics (GA4) — connecteur MCP officiel

**Statut :** officiel, publié par Google.
**Type de connexion :** locale (vous lancez le serveur vous-même).

## Comment se connecter

Le serveur est distribué sous forme de paquet Python `analytics-mcp`, à
lancer avec `pipx` (ou `uvx`) :

```
pipx run analytics-mcp
```

Pour l'ajouter à Claude Code (l'outil en ligne de commande) :

```
claude mcp add analytics-mcp
```

Le dépôt officiel documente aussi une configuration pour d'autres clients
(dont Gemini CLI). Les options exactes (variables d'environnement à
transmettre, etc.) sont détaillées dans le README officiel — reportez-vous-y
avant l'installation.

## Authentification

OAuth via les identifiants applicatifs par défaut de Google (Application
Default Credentials). Portée en lecture seule (`analytics.readonly`).
Variable d'environnement à renseigner : `GOOGLE_APPLICATION_CREDENTIALS`
(chemin vers votre fichier d'identifiants). L'usurpation d'identité par
compte de service est possible en option.

## Documentation officielle

https://github.com/googleanalytics/google-analytics-mcp
