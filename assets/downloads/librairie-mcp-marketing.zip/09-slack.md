# Slack — connecteur MCP officiel

**Statut :** officiel, publié par Slack début 2026 (remplace l'ancien
serveur de référence d'Anthropic, retiré en 2025 après une faille de
sécurité).
**Type de connexion :** distante (URL), mais avec une étape de préparation
supplémentaire par rapport aux autres connecteurs de cette librairie.

## Comment se connecter

URL du serveur officiel :

```
https://mcp.slack.com/mcp
```

Contrairement aux autres connecteurs remote de cette librairie, Slack
demande de créer votre propre application Slack au préalable (interne à
votre organisation ou publiée sur le Slack Marketplace), avec les
permissions (scopes) dont vous avez besoin, puis d'utiliser le Client ID et
le Client Secret de cette application pour vous connecter au serveur MCP.
Une application non publiée et non interne est refusée par Slack.

Exemple de déclaration pour un client compatible (adaptez selon la syntaxe
exacte de votre outil) :

```json
{ "name": "Slack (officiel)", "transport": "http", "url": "https://mcp.slack.com/mcp" }
```

## Authentification

OAuth confidentiel, via l'application Slack que vous créez (Client ID /
Client Secret), avec les scopes utilisateur nécessaires aux outils que vous
souhaitez utiliser.

## Documentation officielle

https://slack.com/help/articles/48855576908307-Guide-to-Model-Context-Protocol-in-Slack
