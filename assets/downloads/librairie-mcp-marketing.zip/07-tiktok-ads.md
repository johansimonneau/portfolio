# TikTok Ads — connecteur MCP officiel

**Statut :** officiel, hébergé par TikTok for Business.
**Type de connexion :** distante (URL, aucune installation).

## Comment se connecter

Deux URLs officielles, selon le profil de votre client IA :

```
https://business-api.tiktok.com/open_mcp/tt-ads-mcp-flat
```

La variante « flat » charge d'un coup l'ensemble des outils (environ 400) —
c'est celle que TikTok recommande pour Claude, qui gère bien un grand nombre
d'outils disponibles.

```
https://business-api.tiktok.com/open_mcp/tt-ads-mcp-layer
```

La variante « layer » ne charge qu'une quarantaine d'outils essentiels au
départ, le reste étant découvert à la demande — utile pour un client à
fenêtre de contexte plus limitée.

Dans les réglages de connecteurs de votre client IA (Claude, ChatGPT...),
ajoutez un connecteur personnalisé et collez l'URL choisie.

## Authentification

Connexion via votre compte TikTok for Business (OAuth). Pas de création
d'app développeur ni de gestion de clé API nécessaire pour cet usage : le
protocole MCP gère l'authentification directement.

## Documentation officielle

https://ads.tiktok.com/resources/help/article/about-tiktok-for-business-mcp-server?lang=en
