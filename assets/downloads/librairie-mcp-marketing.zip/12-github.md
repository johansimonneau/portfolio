# GitHub — connecteur MCP officiel

**Statut :** officiel, publié par GitHub. Deux modes de connexion possibles.
**Type de connexion :** distante (hébergée par GitHub) ou locale (via
Docker), selon votre préférence.

## Option recommandée : serveur distant hébergé par GitHub

URL du serveur officiel :

```
https://api.githubcopilot.com/mcp/
```

Exemple de déclaration officiellement documenté (format VS Code, adaptable à
d'autres clients) :

```json
{
  "servers": {
    "github": {
      "type": "http",
      "url": "https://api.githubcopilot.com/mcp/"
    }
  }
}
```

## Option locale : conteneur Docker

Pour un usage local plutôt que distant, GitHub documente aussi une image
Docker officielle. La configuration exacte (variables d'environnement, port,
mode d'authentification par jeton d'accès personnel via la variable
`GITHUB_PERSONAL_ACCESS_TOKEN`, ou par GitHub App) est détaillée sur le
dépôt officiel — reportez-vous-y avant de choisir cette option, les options
changent régulièrement.

## Authentification

OAuth (flux dans le navigateur, recommandé) ou jeton d'accès personnel
(`GITHUB_PERSONAL_ACCESS_TOKEN`) pour un usage local ou non interactif ;
une GitHub App est aussi documentée pour les usages automatisés.

## Documentation officielle

https://github.com/github/github-mcp-server
