# Canva — connecteur MCP officiel

**Statut :** officiel, hébergé par Canva.
**Type de connexion :** distante (URL, aucune installation).

## Comment se connecter

URL du serveur officiel :

```
https://mcp.canva.com/mcp
```

Avec Claude Code (ligne de commande) :

```
claude mcp add canva --transport http https://mcp.canva.com/mcp
```

Avec un client à interface graphique : ajoutez un connecteur personnalisé
dans les réglages et collez cette URL.

Attention à ne pas confondre ce serveur (plateforme de design Canva) avec le
« Dev MCP server » distinct, documenté séparément par Canva pour les
développeurs qui construisent des applications Canva.

## Authentification

OAuth : à la première connexion, votre client IA ouvre une fenêtre de
connexion Canva, puis réutilise les identifiants obtenus pour les sessions
suivantes.

## Documentation officielle

https://www.canva.dev/docs/apps/mcp/
