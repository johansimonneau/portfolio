# Microsoft Advertising — connecteur MCP officiel

**Statut :** officiel, hébergé par Microsoft.
**Type de connexion :** distante (URL, aucune installation).

## Comment se connecter

URL du serveur officiel, identique pour tous les clients IA :

```
https://partner.api.bingads.microsoft.com/ext/mcp/vnext
```

Dans les réglages de connecteurs de votre client IA (Claude, ChatGPT...),
ajoutez un connecteur personnalisé et collez cette URL. Microsoft documente
aussi la connexion pour Copilot Studio et GitHub Copilot dans VS Code.

## Authentification

Connexion par OAuth via Microsoft Entra ID (anciennement Azure Active
Directory), avec prise en charge des comptes professionnels/scolaires (AAD)
et des comptes Microsoft personnels. Aucun abonnement Azure payant n'est
nécessaire — seule l'inscription (gratuite) de l'application OAuth est
requise, documentée par Microsoft via Azure CLI.

## Documentation officielle

https://learn.microsoft.com/en-us/advertising/guides/mcp-setup?view=bingads-13
