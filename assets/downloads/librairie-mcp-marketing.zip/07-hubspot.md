# HubSpot — connecteur MCP officiel

**Statut :** officiel, hébergé par HubSpot (généralement disponible depuis
avril 2026).
**Type de connexion :** distante (URL, aucune installation).

## Comment se connecter

URL du serveur officiel :

```
https://mcp.hubspot.com
```

Avec Claude Code (ligne de commande) :

```
claude mcp add hubspot --transport http https://mcp.hubspot.com
```

Avec un client à interface graphique : ajoutez un connecteur personnalisé
dans les réglages et collez cette URL.

Un second serveur MCP existe côté HubSpot pour les développeurs qui
construisent des applications HubSpot (différent du serveur CRM ci-dessus) —
voir la documentation officielle pour le distinguer selon votre besoin.

## Authentification

OAuth : à la première connexion, votre client IA ouvre une fenêtre de
connexion HubSpot, puis réutilise les identifiants obtenus pour les sessions
suivantes.

## Documentation officielle

https://developers.hubspot.com/ai-tools/mcp
