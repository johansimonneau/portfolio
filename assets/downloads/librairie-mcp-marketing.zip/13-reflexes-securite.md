# Cinq réflexes sécurité avant de connecter un MCP

Un serveur MCP donne à un agent IA un accès plus ou moins large à vos
données ou à vos comptes. Avant de connecter le moindre outil de cette
librairie :

1. **Préférez toujours le serveur officiel de l'éditeur** à un projet
   communautaire non maintenu, surtout pour des données sensibles (CRM,
   comptes publicitaires, Search Console).

2. **Vérifiez le mode d'authentification.** Un serveur hébergé par
   l'éditeur en OAuth (Semrush, Notion, Canva, HubSpot, Slack...) est
   généralement plus sûr qu'un script local qui vous demande de coller une
   clé API en clair dans un fichier de configuration.

3. **Limitez les permissions à ce qui est nécessaire.** Beaucoup de
   serveurs (Google Analytics, Google Ads) sont volontairement en lecture
   seule — c'est un choix à privilégier tant que vous n'avez pas besoin
   d'écriture.

4. **Ne partagez jamais une clé API dans un outil partagé ou versionné**
   (dépôt Git public, message Slack, document partagé).

5. **Un standard ouvert et récent ne veut pas dire que chaque
   implémentation est sûre.** Le premier serveur MCP de référence
   d'Anthropic pour Slack a été retiré en 2025 après la découverte d'une
   faille de sécurité, avant que Slack ne publie sa propre version
   officielle début 2026. C'est la maintenance et l'audit qui font la
   différence, pas l'ancienneté du standard.

## Une note sur cette librairie elle-même

Les URL et commandes de ce fichier ont été vérifiées sur la documentation
officielle de chaque éditeur au moment de la rédaction, avec le lien vers
cette documentation systématiquement indiqué. Les éditeurs font évoluer
leurs connecteurs MCP régulièrement (nouvelles versions, changements
d'URL) : en cas de doute ou d'erreur de connexion, la documentation
officielle liée dans chaque fichier reste la source de vérité.

— Johan Simonneau, johansimonneau.fr
