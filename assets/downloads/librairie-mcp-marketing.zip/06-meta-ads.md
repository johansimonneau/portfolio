# Meta Ads (Facebook / Instagram) — connecteur MCP officiel

**Statut :** officiel, hébergé par Meta.
**Type de connexion :** distante (URL, aucune installation).

## Comment se connecter

URL du serveur officiel :

```
https://mcp.facebook.com/ads
```

Dans les réglages de connecteurs de votre client IA (Claude, ChatGPT,
Cursor...), ajoutez un connecteur personnalisé et collez cette URL. Meta
indique que cette URL est identique quel que soit le client ou la région.

## Authentification

Connexion via votre compte Facebook (OAuth). L'accès aux comptes
publicitaires suit les mêmes règles de permission que l'API Marketing de
Meta.

## Documentation officielle

https://developers.facebook.com/documentation/ads-commerce/ads-ai-connectors/ads-mcp-server/ads-mcp-server-overview
