# Librairie MCP Marketing — Lisez-moi

Cette librairie contient un fichier par connecteur MCP (Model Context Protocol)
officiel utile en marketing : Analytics, SEO, Publicité, CRM, Productivité,
Design et Code. Chaque fichier indique le mode de connexion réel (URL distante
ou commande locale), vérifié sur la documentation officielle de l'éditeur au
moment de la rédaction — le lien vers cette documentation est toujours donné,
vérifiez-le avant de vous connecter : ces URL et commandes peuvent évoluer.

## Sommaire

1. `01-google-analytics.md` — Analytics & mesure
2. `02-google-search-console.md` — Analytics & mesure (pas de connecteur officiel)
3. `03-semrush.md` — SEO & intelligence concurrentielle
4. `04-ahrefs.md` — SEO & intelligence concurrentielle
5. `05-google-ads.md` — Publicité
6. `06-meta-ads.md` — Publicité
7. `07-hubspot.md` — CRM & automatisation
8. `08-notion.md` — Productivité & contenu
9. `09-slack.md` — Productivité & contenu
10. `10-figma.md` — Design & création
11. `11-canva.md` — Design & création
12. `12-github.md` — Code & déploiement
13. `13-reflexes-securite.md` — À lire avant de connecter quoi que ce soit

## Deux types de connexion

- **Distante (remote)** : vous ajoutez une URL dans les réglages de votre
  client IA (Claude, ChatGPT, Cursor...) — pas d'installation, authentification
  par connexion à votre compte (OAuth).
- **Locale (local)** : vous lancez une commande sur votre machine (souvent via
  `npx`, `pipx` ou `docker`), avec une clé d'API ou des identifiants dans un
  fichier de configuration. Demande un peu plus de mise en place, mais reste
  accessible sans compétence de développeur.

## Mise à jour

Cette librairie est amenée à évoluer avec les publications officielles des
éditeurs. La version la plus récente est toujours disponible sur
https://johansimonneau.fr/kit-mcp-marketing — et la liste complète avec plus
de contexte sur https://johansimonneau.fr/guide-mcp-marketing.

Une question sur la mise en place ? Écrivez à johansimonneau.pro@gmail.com.

— Johan Simonneau, Consultant Traffic Management & Acquisition, johansimonneau.fr
