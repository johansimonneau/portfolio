# Google Search Console — pas de connecteur officiel à ce jour

**Statut :** pas de serveur MCP officiel publié par Google pour Search
Console au moment de la rédaction.

Plusieurs projets communautaires non officiels existent pour connecter
Search Console en MCP. Nous ne recommandons aucun d'entre eux dans cette
librairie : leur maintenance et leur audit de sécurité ne sont pas garantis,
ce qui est un point de vigilance particulier pour un outil qui donne accès à
vos données de positionnement et, selon la configuration, à des actions sur
votre propriété.

## Ce qu'on peut faire en attendant

- Continuer à exporter/consulter Search Console manuellement, ou via son API
  officielle (sans MCP) pour vos automatisations existantes.
- Suivre les annonces officielles de Google sur le sujet plutôt que
  d'adopter un connecteur communautaire non audité pour un outil aussi
  sensible.
- Si vous testez malgré tout un connecteur communautaire, limitez ses
  permissions au strict nécessaire et ne l'utilisez jamais avec une clé
  d'API partagée dans un outil versionné ou collectif.

## Pour aller plus loin

https://johansimonneau.fr/guide-mcp-marketing (section Analytics & mesure)
