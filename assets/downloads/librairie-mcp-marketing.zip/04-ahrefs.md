# Ahrefs — connecteur MCP officiel

**Statut :** officiel, publié par Ahrefs.
**Type de connexion :** locale (à la date de rédaction — voir la remarque
ci-dessous).

## Comment se connecter

Installation du paquet npm officiel :

```
npm install --prefix=~/.global-node-modules @ahrefs/mcp -g
```

Configuration (format `mcpServers`, compatible avec la plupart des clients
MCP) :

```json
{
  "mcpServers": {
    "ahrefs": {
      "command": "npx",
      "args": ["--prefix=~/.global-node-modules", "@ahrefs/mcp"],
      "env": { "API_KEY": "VOTRE_CLE_API" }
    }
  }
}
```

## Remarque importante

Le dépôt officiel de ce serveur local est aujourd'hui archivé, avec une
mention indiquant qu'un serveur distant le remplace désormais. L'URL exacte
de ce serveur distant n'est pas confirmée dans ce dépôt au moment de la
rédaction — vérifiez la documentation officielle Ahrefs avant de choisir
entre l'installation locale ci-dessus et un éventuel serveur distant plus
récent.

## Authentification

Clé d'API Ahrefs (API v3), à renseigner dans la variable d'environnement
`API_KEY`. Ne partagez jamais cette clé dans un dépôt public ou un outil
collectif non sécurisé.

## Documentation officielle

https://github.com/ahrefs/ahrefs-mcp-server
